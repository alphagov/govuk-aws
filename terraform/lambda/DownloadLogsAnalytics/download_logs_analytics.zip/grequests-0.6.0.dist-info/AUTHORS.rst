GRequests is authored by Kenneth Reitz, maintained by Spencer Young and 
various contributors:

Development Leads
`````````````````

- Spencer Phillip Young <spencer.young@spyoung.com>
- Kenneth Reitz <me@kennethreitz.com>

Patches and Suggestions
```````````````````````

Adam Tauber <asciimoo@gmail.com>
Akshat Mahajan <akshatm.bkk@gmail.com>
Alexander Simeonov <agsimeonov@gmail.com>
Antonio A <andrade.antonio@gmail.com>
Chris Drackett <chris@drackett.com>
Eugene Eeo <packwolf58@gmail.com>
Frost Ming <mianghong@gmail.com>
Ian Cordasco <icordasc+github@coglib.com>
Joe Gordon <jogo@pinterest.com>
Luke Hutscal <luke@creaturecreative.com>
Marc Abramowitz <marc@marc-abramowitz.com>
Mathieu Lecarme <mlecarme@bearstech.com>
Michael Newman <newmaniese@gmail.com>
Mircea Ulinic <mirceaulinic@users.noreply.github.com>
Nate Lawson <nate@root.org>
Nathan Hoad <nathan@getoffmalawn.com>
Roman Haritonov <reclosedev@gmail.com>
Ryan T. Dean <ryand@netflix.com>
Spencer Phillip Young <spencer.young@spyoung.com>
Spencer Young <spencer.young@spyoung.com>
Yuri Prezument <y@yprez.com>
koobs <koobs@users.noreply.github.com>
kracekumar <kracethekingmaker@gmail.com>
崔庆才丨静觅 <cqc@cuiqingcai.com>
